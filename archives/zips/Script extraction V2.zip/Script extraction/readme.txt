Pour faire fonctionner ces scripts Python (qui extraient des données de fichiers Word .docx), vous devez installer la bibliothèque python-docx (car elle n'est pas incluse dans Python standard). Les autres modules utilisés (os, re, csv, json) sont déjà dans la bibliothèque standard.

Ouvrez votre console/terminal (pas la console Python interactive, mais cmd.exe sur Windows, Terminal sur macOS/Linux) et collez cette commande :
text

pip install python-docx

Si vous utilisez Python 3 explicitement, utilisez pip3 au lieu de pip. Une fois installé, les scripts devraient tourner sans erreur (assurez-vous que le dossier ./word_forms existe avec vos fichiers .docx). Si vous êtes dans un environnement virtuel (venv), activez-le d'abord.
9,6s

Ce projet est un ensemble de scripts Python conçus pour extraire des données structurées de fichiers Word (.docx) contenant des formulaires médicaux et cliniques liés à une épidémie de MPXV (Monkeypox Virus) ou orthopoxvirus. Les scripts chargent les fichiers, extraient les informations via des expressions régulières (regex), agrègent les données et les exportent au format CSV et JSON.

Les variables extraites couvrent des sections comme les données démographiques, symptômes, examens physiques, résultats PCR, comorbidités, etc., basées sur la structure décrite dans la requête initiale.
Prérequis

    Python: Version 3.6 ou supérieure (testé avec Python 3.8+).
    Dépendances:
        Bibliothèque python-docx pour lire les fichiers .docx.
        Les modules standards Python (os, re, csv, json) sont utilisés, pas besoin d'installation supplémentaire.

Installation

    Installez Python si ce n'est pas déjà fait : Téléchargez depuis python.org.
    Installez la dépendance :
    Ouvrez un terminal (cmd.exe sur Windows, Terminal sur macOS/Linux) et exécutez :
    text

    pip install python-docx

    (Si vous utilisez Python 3 explicitement, utilisez 
    pip3 au lieu de pip.)
    Clonez ou téléchargez les scripts :
        Copiez les fichiers fournis : extract_word.py, parsers.py, aggregator.py, export.py, main.py.
        Placez-les dans un dossier de projet (par exemple, extraction-mpxv).

Configuration

    Préparez le dossier des fichiers Word :
        Créez un sous-dossier nommé word_forms dans le répertoire racine du projet (à côté de main.py).
        Placez vos fichiers .docx contenant les formulaires dans ce dossier. Les noms de fichiers peuvent être arbitraires, mais ils doivent être au format .docx.

    Exemple de structure de dossier :
    text

    extraction-mpxv/
    ├── word_forms/
    │   ├── formulaire_patient1.docx
    │   ├── formulaire_patient2.docx
    │   └── ...
    ├── extract_word.py
    ├── parsers.py
    ├── aggregator.py
    ├── export.py
    └── main.py

Utilisation

    Exécutez le script principal :
        Ouvrez un terminal et naviguez dans le dossier du projet :
        text

        cd chemin/vers/extraction-mpxv

        Lancez le script :
        text

        python main.py

        (Ou 
        python3 main.py si nécessaire.)
    Ce qui se passe :
        Le script charge tous les fichiers .docx du dossier word_forms.
        Il extrait le texte brut de chaque document.
        Il parse le texte avec des regex pour extraire les variables (démographiques, symptômes, PCR, etc.).
        Il agrège les données en une liste de dictionnaires (un par fichier).
        Il exporte les résultats dans deux fichiers :
            extraction.csv : Fichier CSV avec toutes les variables.
            extraction.json : Fichier JSON avec les données structurées.
    Sortie :
        Les fichiers extraction.csv et extraction.json seront créés dans le répertoire racine.
        Ouvrez-les avec un tableur (comme Excel) pour le CSV, ou un éditeur JSON pour le JSON.

Personnalisation

    Ajout de parsers : Si vous avez besoin d'extraire plus de variables, modifiez parsers.py en ajoutant de nouvelles fonctions de parsing avec des regex adaptées.
    Amélioration des regex : Les patterns regex sont basés sur la structure décrite (ex. "Oui/Non", dates au format DD/MMM/YYYY). Testez et ajustez si vos documents varient.
    Gestion des erreurs : Si un fichier .docx est corrompu, une erreur sera affichée, mais le script continuera avec les autres fichiers.

Limitations

    Les regex sont sensibles à la structure exacte des documents. Si le format change (ex. espacements, majuscules), l'extraction peut échouer.
    Pas de support pour les tableaux complexes ou images dans les .docx ; seulement du texte brut.
    Pour de grands volumes de fichiers, testez les performances (le parsing est séquentiel).

Dépannage

    Erreur "ModuleNotFoundError: No module named 'docx'" : Assurez-vous d'avoir installé python-docx.
    Dossier vide : Si aucun fichier n'est trouvé, vérifiez que word_forms existe et contient des .docx.
    Problèmes d'encodage : Les scripts utilisent UTF-8 ; assurez-vous que vos .docx sont encodés correctement.
    Test unitaire : Exécutez python extract_word.py seul pour vérifier le chargement des fichiers (affiche les 500 premiers caractères de chaque).
